create database Banking_System;

use Banking_System;

show databases;
create table Email(Email_id int(13) primary key,Title varchar(50));
describe Email;



create table Email_Tracking(Email_id int(13),Send_Eid int(7),Rec_Eid int(7),constraint pk_table1 primary key(Email_id,Send_Eid,Rec_Eid),Reead char(1));
describe Email_Tracking;


alter table Email_Tracking add foreign key(Email_id) references Email(Email_id) on delete cascade on update cascade;


create table Personsal_details(id int(15) primary key,Fname varchar(20),Lname varchar(20),Address1 varchar(50),Address2 varchar(50),Address3 varchar(50),Email varchar(25),Phone varchar(15),Mobile varchar(15));
describe Persons;
select * from Personsal_details;
SELECT * FROM  Personsal_details ORDER BY  id;
create table Loans(Loan_id int(7) primary key,Duration_by_Month int(10),Interest_Rate int(4),Start_Date Date); 
describe Loans;


create table Transaction_types(Transaction_type char(3) primary key,Transaction_name varchar(25),Tra_desc varchar(999));
describe Transaction_types;



create table Account_types(Type_id char(2) primary key,Type_name varchar(25),Type_desc varchar(999),Rate_range int(4));
describe Account_types;


create table Customers(Customer_id int(7) primary key,Pid int(15),foreign key(Pid) references Personsal_details(id) on delete cascade on update cascade,Cust_type char(1),Loan_id int(7),foreign key(Loan_id) references Loans(Loan_id) on delete cascade on update cascade);

describe Customers;


create table Bank_Branch(Branch_id int(3) primary key,Branch_name varchar(15),Country varchar(35),City varchar(35),Phone varchar(15),Manager_id int(7),bank_name  varchar(20));
describe Bank_Branch;


create table Accounts(Account_id int(7) primary key,Branch_id int(3),foreign key(Branch_id) references Bank_Branch(Branch_id) on delete cascade on update cascade,Customer_id int(7),foreign key(Customer_id) references Customers(Customer_id) on delete cascade on update cascade,Acc_type char(2),foreign key(Acc_type) references Account_types(Type_id) on delete cascade on update cascade,Balance float(100,2),Rate float(9,2),Account_Status varchar(15));
describe Accounts;


create table Departments(Dept_id char(3) primary key,Dept_name varchar(25),Head_of_Dept int(7));
describe Departments;


create table Employees(Emp_id int(7) primary key,Pid int(15),foreign key(Pid) references Personsal_details(id) on delete cascade on update cascade,Branch_id int(3),Dept_id char(3),Manager_id int(7),Salary float(12),Hourly_Rate float(12),Emp_Level int(2),Emp_Password varchar(20));


alter table Employees add foreign key(Dept_id) references Departments(Dept_id) on delete cascade on update cascade;
describe Employees;
alter table Email_Tracking add foreign key(Send_Eid) references Employees(Emp_id) on delete cascade on update cascade;
alter table Email_Tracking add foreign key(Rec_Eid) references Employees(Emp_id) on delete cascade on update cascade;
describe Email_Tracking;


alter table Bank_Branch add foreign key (Manager_id) references employees(emp_id);
describe Bank_Branch;


describe Departments;
create table Transactions(TransAccount_id int(7),Date_Time datetime,constraint pk_table1 primary key(TransAccount_id,Date_Time),
Account_id int(7),foreign key(Account_id) references Accounts(Account_id) on delete cascade on update cascade,
Transaction_type char(3),foreign key(Transaction_type) references Transaction_types(Transaction_type) on delete cascade on update cascade,Emp_id int(7),foreign key(Emp_id) references Employees(Emp_id) on delete cascade on update cascade,Credit char(1));
describe Transactions;
show tables;

insert into Email values(1111,'ABCD');
insert into Email values(1211,'ABDE');
insert into Email values(1311,'XYZ');
insert into Email values(1411,'ABC'); 
insert into Email values(1511,'ABCDEWQ');
insert into Email values(1611,'ABCDXYZ');
insert into Email values(1711,'ABCD1222');
insert into Email values(1811,'ABCDLMN');
insert into Email values(1911,'ABCDUTY678');
insert into Email values(1011,'HGFD');
insert into Email values(1101,'Duty');
insert into Email values(1121,'The population system');
insert into Email values(1231,'Book');
insert into Email values(1331,'WORK');
insert into Email values(1441,'ABCDEFG'); 

select *from Email;


insert into Personsal_details values('123456789','John','Smith','731 Fondren,Houston,TX','731 Fondren,Houston,TX','731 Fondren,Houston,TX','johnsmith4@gmail.com','042-12344455','0300-1234455');
insert into Personsal_details values('333445555','Franklin','Wong','638 Voss,Houston,TX','638 Voss,Houston,TX','638 Voss,Houston,TX','franklinwong@gmail.com','042-12884455','0336-1774455');
insert into Personsal_details values('999887777','Alicia','Zelaya','332 Castle,Spring,TX','332 Castle,Spring,TX','332 Castle,Spring,TX','aliciazel3@yahoo.com','042-12886555','0300-1774455');
insert into Personsal_details values('987654321','Jennifer','Wallace','975 Fire Ook,Humble,TX','975 Fire Ook,Humble,TX','975 Fire Ook,Humble,TX','jennifer33@gmail.com','042-12883456','0345-1774455');
insert into Personsal_details values('666884444','Ramesh','Narayan','291 Berry,Bellaire,TX','291 Berry,Bellaire,TX','291 Berry,Bellaire,TX','rameshnarayan@gmail.com','042-13874455','0336-1634455');
insert into Personsal_details values('453453453','Joyce','English','554 Rice,Houston,TX','554 Rice,Houston,TX','554 Rice,Houston,TX','joyceenglish22@gmail.com','042-12887755','0336-1643455');
insert into Personsal_details values('987987987','Ahmad','Jabbar','980 Dallas,Houston,TX','980 Dallas,Houston,TX','980 Dallas,Houston,TX','ahmadjabbar212@yahoo.com','042-12884115','0336-1645455');
insert into Personsal_details values('888665555','James','Borg','450 Stone,Houston,TX','450 Stone,Houston,TX','450 Stone,Houston,TX','jamesborg@gmail.com','042-43884455','0305-4474455');
insert into Personsal_details values('444556666','Ali','Usman','333 Lake,Houston,TX','333 Lake,Houston,TX','333 Lake,Houston,TX','aliusman@gmail.com','042-43899455','0322-4474455');
insert into Personsal_details values('112223333','Umar','Baig','121 Hollan,Houston,TX','121 Hollan,Houston,TX','121 Hollan,Houston,TX','umarbaig@gmail.com','042-43832455','0345-4474455');

select *from Personsal_details;

insert into Loans values(1111,1,100,'1965-01-09'); 
insert into Loans values(1122,2,200,'2000-03-01'); 
insert into Loans values(4433,1,200,'1985-01-01'); 
insert into Loans values(4355,5,450,'2002-01-20'); 
insert into Loans values(2233,5,500,'2004-10-05');   
insert into Loans values(4567,4,300,'1998-12-02'); 
insert into Loans values(9876,6,1000,'2008-05-09'); 
insert into Loans values(4789,8,1500,'2012-01-02'); 
insert into Loans values(2944,8,2500,'2015-03-03'); 
insert into Loans values(6443,5,5000,'2018-01-01');
desc Loans;
select *from Loans;

insert into Transaction_types values('T11','Account','Account number to which the transaction was booked');
insert into Transaction_types values('T12','Book Date','if transaction value date differs from transaction book date, transaction value date is displayed in narrative');
insert into Transaction_types values('T13','Bank Charge','Bank charges are shown as a separate transaction.');
insert into Transaction_types values('T14','Cash Deposit' ,'Cash is being deposited in the relevant account');
insert into Transaction_types values('T15','Payment','Payment Number are shown in the transaction');
insert into Transaction_types values('T16','Reference Number','Reference Number are shown in the transaction');
insert into Transaction_types values('T17','Debit or Credit','transaction of oth debit or credit amount');
insert into Transaction_types values('T18','Counter Party','Narrative purpose of the transaction, counterparty for payments');
desc transaction_types;
select *from Transaction_types;

insert into Account_types values('A1','Saving','keep aside some extra funds for emergencies',2);
insert into Account_types values('A2','Current','money may be withdrawn without notice',5);
insert into Account_types values('A3','Current','money may be withdrawn without notice',3);
insert into Account_types values('A4','Saving','keep aside some extra funds for emergencies',10);
insert into Account_types values('A5','Current','money may be withdrawn without notice',10);
insert into Account_types values('A6','Saving','keep aside some extra funds for emergencies',20);
insert into Account_types values('A7','Current','money may be withdrawn without notice',50);
insert into Account_types values('A8','Saving','keep aside some extra funds for emergencies',50);
insert into Account_types values('A9','Current','money may be withdrawn without notice',100);
insert into Account_types values('A0','Saving','keep aside some extra funds for emergencies',150);
desc Account_types;
select *from Account_types;

insert into Customers values ('111111','112223333','M','1111');
insert into Customers values ('222222','123456789','F','1122');
insert into Customers values ('333333','112223333','F','4433');
insert into Customers values ('444444','666884444','F','4355');
insert into Customers values ('555555','987987987','M','2233');
insert into Customers values ('666666','666884444','M','4567');
insert into Customers values ('777777','987654321','F','9876');
insert into Customers values ('888888','123456789','F','4789');
insert into Customers values ('999999','888665555','M','2944');
insert into Customers values ('101010','123456789','F','6443');
desc customers;
select * from customers;



insert into Bank_Branch values ('001','IQBAL TOWN','PAKISTAN','LAHORE','042-1111111','70001','Allied Bank Ltd');
insert into Bank_Branch values ('002','MODEL TOWN','PAKISTAN','LAHORE','042-2222222','70002','Allied Bank Ltd');
insert into Bank_Branch values ('003','JOHAR TOWN','PAKISTAN','ISLAMABAD','051-3333333','70003','Habib Bank Ltd');
insert into Bank_Branch values ('004', 'PECO ROAD TOWNSHIP','PAKISTAN','LAHORE','042-4787874','70004','Standard Chartered Bank Ltd');
insert into Bank_Branch values ('005','SHADMAN','PAKISTAN','RAWALPINDI','051-9999999','70005','Bank AL-Habib');
insert into Bank_Branch values ('006','KOT LAQPAT','PAKISTAN','LAHORE','042-4566545','70006','MCB Bank Ltd');
insert into Bank_Branch values ('007','NEW KARACHI','PAKISTAN','KARACHI','021-8574254','70007','Faysal Bank Ltd');
insert into Bank_Branch values ('008','SHAH FAISAL COULONY','PAKISTAN','KARACHI','021-9999874','70008','Al Baraka Bank Ltd');
insert into Bank_Branch values ('009','GULBERG 2','PAKISTAN','LAHORE','042-1234321','70009','Faysal Bank Ltd');
insert into Bank_Branch values ('010',' EME ','PAKISTAN','LAHORE','042-9517536','70010','Al Baraka Bank Ltd' );


desc bank_branch;
select *from Bank_Branch;


insert into  employees values ('70001','112223333','001','D04','70001','75000','650','4','abcd0225');
insert into  employees values ('70002','987987987','002','D02','70001','750000','1000','1','abcd0227');
insert into  employees values ('70003','888665555','003','D05','70002','55000','550','7','abcd0220');
insert into  employees values ('70004','453453453','001','D09','70003','25000','300','5','abcd0221');
insert into  employees values ('70005','123456789','007','D03','70001','45500','450','9','abcd0228');
insert into  employees values ('70006','666884444','005','D07','70002','65780','476','5','abcd0232');
insert into  employees values ('70007','112223333','009','D05','70003','98400','789','2','abcd0233');
insert into  employees values ('70008','453453453','004','D08','70004','150000','850','5','abcd0238');
insert into  employees values ('70009','987987987','008','D06','70006','175000','950','3','abcd0245');
insert into  employees values ('70010','888665555','002','D05','70006','850000','1200','10','abcd1265');
desc employees;
select *from Employees;

delete from employees where emp_id= 70002;

insert into departments values ('D01','HRD','70001');
insert into departments values ('D02','INFORMATION','70004');
insert into departments values ('D03','LOAN','70006');
insert into departments values ('D04','CUSTOMER SERVICE','70008');
insert into departments values ('D05','ATM','70010');
insert into departments values ('D06','CUSTOMER SERVICE','70009');
insert into departments values ('D07','ATM','70008');
insert into departments values ('D08','HRD','70002');
insert into departments values ('D09','LOAN','70001');
insert into departments values ('D10','INFORMATION','70001');
desc departments;
select *from departments;


insert into accounts values ('990','002','555555','A2','25000.95','25.75','test');
insert into accounts values ('991','004','111111','A4','75000.45','45.75','active');
insert into accounts values ('992','006','333333','A6','155000.250','55.75','active');
insert into accounts values ('993','008','111111','A2','2507000.95','15.75','active');
insert into accounts values ('994','006','444444','A8','65000.95','35.75','test');
insert into accounts values ('995','001','555555','A2','98000.45','175.75','active');
insert into accounts values ('996','006','777777','A8','498000.45','15.75','test');
insert into accounts values ('997','004','222222','A6','698000.45','12.45','active');
insert into accounts values ('998','003','333333','A2','98000.45','175.75','test');
insert into accounts values ('999','009','999999','A7','1753000.45','45.75','active');
desc accounts;
select * from accounts;


delete from accounts where account_id=999;

insert into transactions values ('400','2019-06-15','991','T12','70001','C');
insert into transactions values ('401','2019-06-14','993','T14','70002','C');
insert into transactions values ('402','2019-06-10','995','T12','70003','C');
insert into transactions values ('403','2019-06-19','997','T15','70004','C');
insert into transactions values ('404','2019-05-15','999','T11','70005','D');
insert into transactions values ('405','2019-05-25','990','T13','70006','C');
insert into transactions values ('406','2019-05-05','992','T12','70007','C');
insert into transactions values ('407','2019-04-13','993','T18','70008','D');
insert into transactions values ('408','2019-04-07','994','T14','70009','D');
insert into transactions values ('409','2019-03-14','991','T14','70009','C');
desc transactions;
select * from transactions;

insert into Email_Tracking values(1111,70001,70002,'R');
insert into Email_Tracking values(1911,70005,70007,'R');
insert into Email_Tracking values(1211,70010,70005,'N');
insert into Email_Tracking values(1101,70003,70006,'R');
insert into Email_Tracking values(1011,70008,70009,'N');
insert into Email_Tracking values(1331,70002,70003,'N');
insert into Email_Tracking values(1121,70004,70010,'N');
insert into Email_Tracking values(1231,70006,70001,'R');
insert into Email_Tracking values(1811,70007,70004,'R');
insert into Email_Tracking values(1411,70009,70008,'N');
desc  Email_Tracking;
select *from Email_Tracking;



DELETE FROM Email_tracking WHERE Email_id='1111';



#1
select Bank_name,Branch_name from Bank_Branch where city='Lahore';
#2
select c.Customer_id from Customers c join Accounts ac on c.customer_id=ac.customer_id join Account_types act on ac.Acc_type=act.type_id where act.Type_name='Saving'; 
#3
select p.id,p.Fname,p.Lname,e.salary from personsal_details p join employees e on p.id=e.pid where e.salary Between 50000 and 95000;
#4
select e.emp_id from employees e join employees emp on emp.Emp_id=e.manager_id where e.Emp_level >= 5;
#5
select p.Fname,P.Lname from personsal_details p join Employees e on p.id=e.pid join departments d on e.dept_id=d.dept_id where dept_name='Customer Service';
#6
select d.dept_id,d.dept_name from departments d join Employees e on d.dept_id=e.dept_id;
#7
select p.Fname,p.Lname from personsal_details p join Customers c on p.id=c.pid join accounts a on c.customer_id=a.customer_id join account_types act on a.Acc_type=act.type_id where type_name='Current';
#8
select p.Fname,P.Lname from personsal_details p join Customers c on p.id=c.pid where c.cust_type='M';
#9
select p.id,p.Fname,p.Lname from personsal_details p join customers c on p.id=c.pid join Accounts ac on c.customer_id=ac.customer_id join Bank_Branch b on ac.Branch_id=b.Branch_id where b.bank_name ='Faysal Bank';
#10
select p.Fname,p.Lname from personsal_details p join Employees e on p.id=e.pid join Transactions t on e.Emp_id=t.Emp_id where t.credit='D'; 
#11
select e.Emp_id from Employees e join Email_Tracking em on e.Emp_id=em.send_eid where em.reead='R';
#12
select e.Emp_id from Employees e join Email_Tracking em on e.Emp_id=em.rec_eid where em.reead='R';
#13
select e.Emp_id from Employees e join Email_Tracking em on e.Emp_id=em.send_eid where em.reead='N';
#14
select e.Emp_id from Employees e join Email_Tracking em on e.Emp_id=em.rec_eid where em.reead='N';
#15
select e.email_id from email e join email_tracking em on e.email_id=em.email_id where e.title='The population system';
#16
select e.Emp_id from Employees e join Bank_Branch b on e.Emp_id=b.manager_id where b.branch_name='Johar Town';
#17
select p.Fname,p.Lname from personsal_details p join Employees e on p.id=e.pid join Bank_Branch b on e.Emp_id=b.manager_id where b.branch_name='Johar Town';
#18
select e.Emp_id from Employees e join Bank_Branch b on e.branch_id=b.branch_id where b.branch_name='Johar Town';
#19
select p.Fname,p.Lname from personsal_details p join Employees e on p.id=e.pid join Bank_Branch b on e.branch_id=b.branch_id where b.branch_name='Johar Town';





desc employees;

insert into employees value ('12','123456789','1234','D01','76','2000','20','14','85678');

delete from employees where emp_id = 12;

UPDATE employees SET  Salary='12',Emp_Password ='123456789' where emp_id=70001;
