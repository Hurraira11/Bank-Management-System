<?php
$connect = new PDO("mysql:host=localhost;dbname=Banking_System", "root", "");

$query = "SELECT * FROM Loans ORDER BY  Loan_id";

$statement = $connect->prepare($query);

$statement->execute();

$result = $statement->fetchAll();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin 2 - Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>


    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fab fa-bitcoin"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Bank Management System</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="/bank_management_system">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Features
            </div>

            <li class="nav-item">
                <a class="nav-link" href="employees.php">
					<i class="fa fa-user-tie"></i>
                    <span>Employees</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="accounts.php">
                    <i class="fa fa-file-invoice"></i>
                    <span>Accounts</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="personal.php">
                    <i class="fa fa-user fa-fw"></i>
                    <span>Personal Details</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="customers.php">
                    <i class="fa fa-users"></i>
                    <span>Customers</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="departments.php">
                    <i class="fa fa-building"></i>
                    <span>Departments</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="email.php">
                    <i class="fa fa-envelope" aria-hidden="true"></i>
                    <span>Email</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="email_tracking.php">
                    <i class="fa fa-inbox"></i>
                    <span>Email Tracking</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="transactions.php">
                    <i class="fa fa-repeat"></i>
                    <span>Transactions</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="transaction_types.php">
                    <i class="fa fa-list"></i>
                    <span>Transaction Types</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="bank_branches.php">
                    <i class="fa fa-bars"></i>
                    <span>Bank Branches</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="loans.php">
                    <i class="fa fa-door-open"></i>
                    <span>Loans</span></a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="account_types.php">
                    <i class="fa fa-layer-group"></i>
                    <span>Account Types</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                               <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
					<marquee class="news-scroll" behavior="scroll" direction="left" onmouseover="this.stop();" onmouseout="this.start();"> 
					
					UCP Bank now have more than 250 branches nation wide 
					<span style="height: 6px;width: 6px;margin-left: 3px;margin-right: 3px;margin-top: 2px !important;background-color: rgb(207, 23, 23);border-radius: 50%;display: inline-block"></span> 
					New Car finance policy Available
					
					<span style="height: 6px;width: 6px;margin-left: 3px;margin-right: 3px;margin-top: 2px !important;background-color: rgb(207, 23, 23);border-radius: 50%;display: inline-block"></span>
					New Saving policy available please visit nearest branch to get more information
					
					<span style="height: 6px;width: 6px;margin-left: 3px;margin-right: 3px;margin-top: 2px !important;background-color: rgb(207, 23, 23);border-radius: 50%;display: inline-block"></span> 
					Beaware of scammers 
					
					</marquee>
					
					<div class="topbar-divider d-none d-sm-block"></div>
					<div class="d-flex flex-row flex-grow-1 flex-fill justify-content-center bg-danger py-2 text-white px-1 news"><span class="d-flex align-items-center">Latest News</span></div>
					
                </nav>

                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Loans</h1>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Loans Data</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
									<thead>
									<tr>
									<th>Loan ID</th>
									<th>Loan Duration</th>
									<th>Interest Rate</th>
									<th>Starting Date</th>
									</tr>
									</thead>
									<tbody id="table_data">
									<?php
									foreach($result as $row)
									{
									echo '
									<tr>
									<td>'.$row["Loan_id"].'</td>
									<td>'.$row["Duration_by_Month"].'</td>
									<td>'.$row["Interest_Rate"].'</td>
									<td>'.$row["Start_Date"].'</td>
									</tr>
									';
									}
									?>
									</tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; UCP BANK 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>